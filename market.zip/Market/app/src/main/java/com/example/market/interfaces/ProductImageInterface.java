package com.example.market.interfaces;

import com.example.market.marketDatabase.Image;

public interface ProductImageInterface {

    void onClickToRemove(Image image);
}
