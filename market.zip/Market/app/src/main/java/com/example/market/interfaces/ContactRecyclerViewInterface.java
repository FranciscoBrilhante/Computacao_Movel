package com.example.market.interfaces;

public interface ContactRecyclerViewInterface {
    void onClick(int profileID);
}

