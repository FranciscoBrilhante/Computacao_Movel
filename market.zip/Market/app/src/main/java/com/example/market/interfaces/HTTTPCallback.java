package com.example.market.interfaces;

import org.json.JSONObject;

public interface HTTTPCallback {
    void onComplete(JSONObject data);
}
